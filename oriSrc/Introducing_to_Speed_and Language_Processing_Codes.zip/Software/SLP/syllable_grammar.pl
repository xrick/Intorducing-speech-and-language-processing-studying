/* SYLLABLE_GRAMMAR.PL						*/
/* Simple grammar of syllable structure			*/

syllable_sequence --> syllable.
syllable_sequence --> syllable, syllable_sequence.

syllable --> onset, rime.

rime --> nucleus, coda.

onset --> inner_onset, sonorant.	/* maximal Onset hypothesis */
onset --> inner_onset.
onset --> [h].

inner_onset --> [s], obstruent.
inner_onset --> obstruent.
inner_onset --> [].

nucleus --> long_vowel.
nucleus --> diphthong.
nucleus --> short_vowel.

coda --> [].
coda --> sonorant.
coda --> obstruent.
coda --> sonorant, sonorant.
coda --> sonorant, obstruent.
coda --> obstruent, obstruent.

obstruent --> [p].	obstruent --> [t].	obstruent --> [k].
obstruent --> [b].	obstruent --> [d].	obstruent --> [g].
obstruent --> ['C'].	obstruent --> ['J'].	
obstruent --> [f].	obstruent --> ['T'].
obstruent --> [s].	obstruent --> ['S'].
obstruent --> [v].	obstruent --> ['D']. 	obstruent --> [z].

sonorant --> [r].	sonorant --> [l].
sonorant --> [w].	sonorant --> [j].
sonorant --> [m].	sonorant --> [n].

short_vowel --> ['I'].
short_vowel --> [e].
short_vowel --> ['&'].
short_vowel --> [0].
short_vowel --> ['U'].
short_vowel --> ['@'].
short_vowel --> ['V'].

long_vowel --> [i].
long_vowel --> ['A'].
long_vowel --> ['O'].
long_vowel --> [u].
long_vowel --> [3].

diphthong --> [e,'I'].
diphthong --> [a,'I'].
diphthong --> [o,'I'].
diphthong --> ['@','U'].
diphthong --> [a,'U'].
diphthong --> ['I','@'].
diphthong --> [e,'@'].
diphthong --> ['U','@'].
diphthong --> [j,u].

loop:- syllable(S,[]), write(S), nl, fail.

