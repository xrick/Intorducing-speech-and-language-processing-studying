/* NFST1.PL	 A nondeterministic finite-state transducer 		*/
/*		 to relate English-like phoneme strings to spellings	*/

accept(OrthString,PhonString):- 
move(s1,OrthString,PhonString,[],[]), 
	name(Orth,OrthString), name(Phon,PhonString),
	write(Orth), write(' '), write(Phon), nl.

move(State1,Orth,Phon,[],[]):-
	transition(State1,Orth:Phon,end).
move(State1,Orth,Phon,OrthRem,PhonRem):-
	transition(State1,OrthSym:PhonSym,State2),
	append(OrthSym,OrthRest,Orth),
	append(PhonSym,PhonRest,Phon),
	move(State2,OrthRest,PhonRest,OrthRem,PhonRem).

/* Enumerate all acceptable strings */

loop:- accept(A,B), fail.	

transition(s1,"s":"s",s2).
transition(s1,"p":"p",s3).
transition(s1,"t":"t",s3).
transition(s1,"c":"k",s3).
transition(s1,"b":"b",s3).
transition(s1,"d":"d",s3).
transition(s1,"g":"g",s3).
transition(s1,"f":"f",s3).
transition(s1,"ph":"f",s3).
transition(s1,"th":"T",s3).
transition(s1,"sh":"S",s3).
transition(s1,"p":"p",s4).
transition(s1,"t":"t",s4).
transition(s1,"c":"k",s4).
transition(s1,"k":"k",s4).
transition(s1,"b":"b",s4).
transition(s1,"d":"d",s4).
transition(s1,"g":"g",s4).
transition(s1,"gu":"g",s4).
transition(s1,"f":"f",s4).
transition(s1,"ph":"f",s4).
transition(s1,"v":"v",s4).
transition(s1,"s":"s",s4).
transition(s1,"c":"s",s4).
transition(s1,"ps":"s",s4).
transition(s1,"th":"T",s4).
transition(s1,"th":"D",s4).
transition(s1,"sh":"S",s4).
transition(s1,"h":"h",s4).
transition(s1,"ch":"C",s4).
transition(s1,"j":"J",s4).
transition(s1,"g":"J",s4).
transition(s1,"r":"r",s4).
transition(s1,"wr":"r",s4).
transition(s1,"l":"l",s4).
transition(s1,"w":"w",s4).
transition(s1,"wh":"w",s4).
transition(s1,"y":"j",s4).
transition(s1,"m":"m",s4).
transition(s1,"n":"n",s4).
transition(s1,"kn":"n",s4).
transition(s1,"qu":"kw",s4).
transition(s1,"":"",s4).
transition(s2,"p":"p",s3).
transition(s2,"t":"t",s3).
transition(s2,"c":"k",s3).
transition(s2,"k":"k",s3).
transition(s2,"p":"p",s4).
transition(s2,"t":"t",s4).
transition(s2,"c":"k",s4).
transition(s2,"k":"k",s4).
transition(s2,"m":"m",s4).
transition(s2,"n":"n",s4).
transition(s2,"l":"l",s4).
transition(s2,"w":"w",s4).
transition(s2,"ph":"f",s4).
transition(s2,"qu":"kw",s4).
transition(s3,"r":"r",s4).
transition(s3,"l":"l",s4).
transition(s3,"w":"w",s4).
transition(s3,"":"",s4).
transition(s3,"ue":"ju",s7).
transition(s4,"i":"I",s5).
transition(s4,"e":"e",s5).
transition(s4,"a":"&",s5).
transition(s4,"u":"V",s5).
transition(s4,"o":"0",s5).
transition(s4,"u":"U",s5).
transition(s4,"oo":"U",s5).
transition(s4,"ai":"eI",s7).
transition(s4,"ay":"eI",s7).
transition(s4,"a":"eI",s7).
transition(s4,"ar":"A",s7).
transition(s4,"air":"e@",s7).
transition(s4,"ea":"i",s7).
transition(s4,"ee":"i",s7).
transition(s4,"ear":"I@",s7).
transition(s4,"eer":"I@",s7).
transition(s4,"er":"3",s7).
transition(s4,"ir":"3",s7).
transition(s4,"ur":"3",s7).
transition(s4,"or":"O",s7).
transition(s4,"au":"O",s7).
transition(s4,"aw":"O",s7).
transition(s4,"u":"u",s7).
transition(s4,"oo":"u",s7).
transition(s4,"o":"@U",s7).
transition(s4,"oa":"@U",s7).
transition(s4,"ow":"@U",s7).
transition(s4,"ou":"aU",s7).
transition(s4,"ow":"aU",s7).
transition(s4,"our":"U@",s7).
transition(s4,"oy":"oI",s7).
transition(s4,"oi":"oI",s7).
transition(s4,"ie":"aI",s7).
transition(s4,"y":"aI",s7).
transition(s4,"ew":"ju",s7).
transition(s5,"d":"d",s6).
transition(s5,"l":"l",s8).
transition(s5,"m":"m",s8).
transition(s5,"n":"n",s8).
transition(s5,"ng":"N",s8).
transition(s5,"b":"b",s9).
transition(s5,"g":"g",s9).
transition(s5,"th":"D",s9).
transition(s5,"ve":"v",s9).
transition(s5,"ll":"l",s9).
transition(s5,"dge":"J",s10).
transition(s5,"z":"z",s10).
transition(s5,"s":"z",s10).
transition(s5,"p":"p",s11).
transition(s5,"t":"t",s11).
transition(s5,"ck":"k",s11).
transition(s5,"f":"f",s11).
transition(s5,"ff":"f",s11).
transition(s5,"d":"d",s11).
transition(s5,"l":"l",s11).
transition(s5,"n":"n",s11).
transition(s5,"tch":"C",s12).
transition(s5,"ss":"s",s12).
transition(s5,"sh":"S",s12).
transition(s5,"x":"ks",s12).
transition(s6,"":"",s9).
transition(s6,"th":"T",s13).
/* State 7 is an end state if there are no more letters left */
transition(s7,"":"",end).	
transition(s7,"l":"l",s8).
transition(s7,"m":"m",s8).
transition(s7,"n":"n",s8).
transition(s7,"b":"b",s9).
transition(s7,"de":"d",s9).
transition(s7,"ed":"d",s9).
transition(s7,"d":"d",s9).
transition(s7,"gue":"g",s9).
transition(s7,"ve":"v",s9).
transition(s7,"the":"D",s9).
transition(s7,"ge":"J",s10).
transition(s7,"se":"z",s10).
transition(s7,"es":"z",s10).
transition(s7,"ze":"z",s10).
transition(s7,"ge":"Z",s10).
transition(s7,"p":"p",s11).
transition(s7,"t":"t",s11).
transition(s7,"k":"k",s11).
transition(s7,"f":"f",s11).
transition(s7,"ch":"C",s12).
transition(s7,"ce":"s",s12).
transition(s7,"sh":"S",s12).
transition(s7,"th":"T",s13).
/* State 8 is an end state if there are no more letters left */
transition(s8,"":"",end).	
transition(s8,"b":"b",s9).
transition(s8,"d":"d",s9).
transition(s8,"ve":"v",s9).
transition(s8,"":"",s9).
transition(s8,"ge":"J",s10).
transition(s8,"p":"p",s11).
transition(s8,"t":"t",s11).
transition(s8,"k":"k",s11).
transition(s8,"f":"f",s11).
transition(s8,"":"",s11).
transition(s8,"ch":"C",s12).
transition(s8,"s":"s",s12).
transition(s8,"sh":"S",s12). 
/* State 9 is an end state if there are no more letters left */

transition(s9,"":"",end).	
transition(s9,"s":"z",s10).
transition(s9,"":"",s10).
/* State 10 is an end state if there are no more letters left */
transition(s10,"":"",end).	
transition(s10,"d":"d",s14).
/* State 11 is an end state if there are no more letters left */
transition(s11,"":"",end).	
transition(s11,"s":"s",s12).
transition(s11,"":"",s12).
/* State 12 is an end state if there are no more letters left */
transition(s12,"":"",end).	
transition(s12,"t":"t",s13).
transition(s12,"th":"T",s13).
/* State 13 is an end state if there are no more letters left */
transition(s13,"":"",end).	
transition(s13,"s":"s",s14).
/* State 14 is an end state if there are no more letters left */
transition(s14,"":"",end).	

