/* stolcke_grammar1.pl */
/* (after Stolcke 1995) */

s --> np, vp.
np --> det, n.
vp --> vt, np.
vp --> vi, pp.
pp --> p, np.

det --> [a].
n --> [circle].
n --> [square].
n --> [triangle].
vt --> [touches].
vi --> [is].
p --> [above].
p --> [below].
