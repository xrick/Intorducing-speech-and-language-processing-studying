/* SIMPLE_PARWAVE.C */

#include <stdio.h>
#include <math.h>
#include "proto.h"
#include "parwave.h"

/* function prototypes for functions private to this file */

static float impulsive_source PROTO((klatt_global_ptr));
static void pitch_synch_par_reset PROTO((klatt_global_ptr,klatt_frame_ptr)); 
static float gen_noise PROTO((float,klatt_global_ptr));
static float DBtoLIN PROTO((long));
static void frame_init PROTO((klatt_global_ptr,klatt_frame_ptr)); 
static float resonator PROTO((resonator_ptr, float));
static float antiresonator PROTO((resonator_ptr, float));
static void setabc PROTO((long,long,resonator_ptr,klatt_global_ptr));
static void setzeroabc PROTO((long,long,resonator_ptr,klatt_global_ptr));

/* function IMPULSIVE_SOURCE

Generate a low pass filtered train of impulses as an approximation of 
a natural excitation waveform. Low-pass filter the differentiated impulse 
with a critically-damped second-order filter, time constant proportional 
to Kopen. */

static float impulsive_source(klatt_global_ptr globals) {
  static float doublet[] = {0.0,13000000.0,-13000000.0};
  static float vwave;

  if (globals->nper < 3) 
      vwave = doublet[globals->nper];
  else 
      vwave = 0.0;
  return(resonator(&(globals->rgl),vwave));
}

/* function GEN_NOISE

Random number generator (return a number between -8191 and +8191) */

static float gen_noise(float noise, klatt_global_ptr globals) {
  long temp;

  temp = rand();
  globals->nrand = (temp >> 1) - 8191;  
  noise = globals->nrand;
  return(noise);
}

/* function RESONATOR

This is a generic resonator function. Internal memory for the resonator
is stored in the globals structure. */

static float resonator(resonator_ptr r, float input) {
 register float x = r->a * input + r->b * r->p1 + r->c * r->p2;
 r->p2 = r->p1;
 r->p1 = x;
 return x;
}

/* function ANTIRESONATOR

This is a generic anti-resonator function. The code is the same as resonator 
except that a,b,c need to be set with setzeroabc() and we save inputs in 
p1/p2 rather than outputs. There is currently only one of these - "rnz"
Output = (rnz.a * input) + (rnz.b * oldin1) + (rnz.c * oldin2) */

static float antiresonator(resonator_ptr r, float input) {
 register float x = r->a * input + r->b * r->p1 + r->c * r->p2;
 r->p2 = r->p1;
 r->p1 = input;
 return x;
}

/* function SETABC

Convert formant freqencies and bandwidth into resonator difference 
equation constants. */

static void setabc(long int f, long int bw, resonator_ptr rp, klatt_global_ptr globals) {
 float r;
 double arg;

/* Let r  =  exp(-pi bw t) */

 arg = globals->minus_pi_t * bw;
 r = exp(arg);

/* Let c  =  -r**2 */

 rp->c = -(r * r);

/* Let b = r * 2*cos(2 pi f t) */

 arg = globals->two_pi_t * f;
 rp->b = r * cos(arg) * 2.0;

/* Let a = 1.0 - b - c */

 rp->a = 1.0 - rp->b - rp->c;
}

/* function SETZEROABC

Convert formant freqencies and bandwidth into anti-resonator difference 
equation constants. */

static void setzeroabc(long int f, long int bw, resonator_ptr rp, klatt_global_ptr globals) {
 float r;
 double arg;

/* First compute ordinary resonator coefficients */
/* Let r  =  exp(-pi bw t) */

 arg = globals->minus_pi_t * bw;
 r = exp(arg);

/* Let c  =  -r**2 */

 rp->c = -(r * r);

/* Let b = r * 2*cos(2 pi f t) */

 arg = globals->two_pi_t * f;
 rp->b = r * cos(arg) * 2.;

/* Let a = 1.0 - b - c */

 rp->a = 1.0 - rp->b - rp->c;

/* Now convert to antiresonator coefficients (a'=1/a, b'=b/a, c'=c/a) */

 rp->a = 1.0 / rp->a;
 rp->c *= -rp->a;
 rp->b *= -rp->a;
}

/* function PARWAVE - Converts synthesis parameters to a waveform. */

void parwave(klatt_global_ptr globals,klatt_frame_ptr frame,int *output) {
  float temp;
  float outbypas;
  float out;
  long n4;
  float frics;
  float glotout;
  float aspiration;
  float casc_next_in;
  float par_glotout;
  static float noise;
  static float voice;
  static float glotlast;
  static float sourc;

  frame_init(globals,frame);  /* get parameters for next frame of speech */

  /* MAIN LOOP, for each output sample (ns) of current frame: */

  for (globals->ns=0;globals->ns<globals->nspfr;globals->ns++) {

    /* Get low-passed random number for aspiration and frication noise */

    noise = gen_noise(noise,globals);

    /* Amplitude modulate noise (reduce noise amplitude during
       second half of glottal period) if voicing simultaneously present. */

    if (globals->nper > globals->nmod) noise *= 0.5;

    /* Compute frication noise */

    frics = globals->amp_frica * noise;

    /* Compute voicing waveform. Run glottal source simulation at 4 
       times normal sample rate to minimize quantization noise in 
       period of female voice. */

    for (n4=0; n4<4; n4++) {
	voice = impulsive_source(globals);
	/* Figure 2.5 plots the value of voice, taken here		*/

        /* Reset period when counter 'nper' reaches T0 			*/

        if (globals->nper >= globals->T0) {
	    globals->nper = 0;
	    pitch_synch_par_reset(globals,frame);
        }

        /* Low-pass filter voicing waveform before downsampling from 4*samrate
	   to samrate samples/sec.  Resonator f=.09*samrate, bw=.06*samrate */

        voice = resonator(&(globals->rlp),voice);

        /* Increment counter that keeps track of 4*samrate samples per sec */

        globals->nper++;
    }

    /* Set amplitude of voicing */

    glotout = globals->amp_voice * voice;		/* glottal output */
    par_glotout = globals->par_amp_voice * voice;	/* to parallel branch */

    /* Compute aspiration amplitude and add to voicing source */

    aspiration = globals->amp_aspir * noise;
    glotout += aspiration;
    par_glotout += aspiration;

    /* Cascade vocal tract, excited by laryngeal sources,
       nasal antiresonator and resonator, then formants F5, F4, F3, F2, F1. */

      casc_next_in = antiresonator(&(globals->rnz),glotout);
      casc_next_in = resonator(&(globals->rnpc),casc_next_in);

      if (globals->nfcascade >= 5) 
	casc_next_in = resonator(&(globals->r5c),casc_next_in);
      if (globals->nfcascade >= 4) 
	casc_next_in = resonator(&(globals->r4c),casc_next_in);
      if (globals->nfcascade >= 3) 
	casc_next_in = resonator(&(globals->r3c),casc_next_in);
      if (globals->nfcascade >= 2) 
	casc_next_in = resonator(&(globals->r2c),casc_next_in);
      if (globals->nfcascade >= 1) 
	out = resonator(&(globals->r1c),casc_next_in);
      if (globals->nfcascade < 1)
        out = glotout;

    /* Excite parallel F1 and FNP by voicing waveform */

    sourc = par_glotout;        /* Source is voicing plus aspiration */

    /* Standard parallel vocal tract Formants F6,F5,F4,F3,F2, 
       outputs added with alternating sign. Sound sourc for other 
       parallel resonators is frication plus first difference of 
       voicing waveform. */

    out += resonator(&(globals->r1p),sourc);
    out += resonator(&(globals->rnpp),sourc);

    sourc = frics + par_glotout - glotlast;
    glotlast = par_glotout;

    out = resonator(&(globals->r6p),sourc) - out;
    out = resonator(&(globals->r5p),sourc) - out;
    out = resonator(&(globals->r4p),sourc) - out;
    out = resonator(&(globals->r3p),sourc) - out;
    out = resonator(&(globals->r2p),sourc) - out;

    outbypas = globals->amp_bypas * sourc;
    out = outbypas - out;
    out = resonator(&(globals->rout),out);
    temp = out * globals->amp_gain0;  /* Convert back to integer */

    if (temp < -32768) 
      temp = -32768;
    if (temp >  32767) 
      temp =  32767;

    *output++ = (int) temp;
  }
}

/* function PARWAVE_INIT

Initialises all parameters used in parwave, sets resonator internal memory
to zero. */

void parwave_init(klatt_global_ptr globals){
  globals->FLPhz = (950 * globals->samrate) / 10000;
  globals->BLPhz = (630 * globals->samrate) / 10000;
  globals->minus_pi_t = -PI / globals->samrate;
  globals->two_pi_t = -2.0 * globals->minus_pi_t;
  setabc(globals->FLPhz,globals->BLPhz,&(globals->rlp),globals);
  globals->nper = 0;
  globals->T0 = 0;

  globals->rnpp.p1=0;
  globals->r1p.p1=0;
  globals->r2p.p1=0;
  globals->r3p.p1=0;
  globals->r4p.p1=0;
  globals->r5p.p1=0;
  globals->r6p.p1=0;
  globals->r1c.p1=0;
  globals->r2c.p1=0;
  globals->r3c.p1=0;
  globals->r4c.p1=0;
  globals->r5c.p1=0;
  globals->r6c.p1=0;
  globals->r7c.p1=0;
  globals->r8c.p1=0;
  globals->rnpc.p1=0;
  globals->rnz.p1=0;
  globals->rgl.p1=0;
  globals->rlp.p1=0;
  globals->rout.p1=0;
  
  globals->rnpp.p2=0;
  globals->r1p.p2=0;
  globals->r2p.p2=0;
  globals->r3p.p2=0;
  globals->r4p.p2=0;
  globals->r5p.p2=0;
  globals->r6p.p2=0;
  globals->r1c.p2=0;
  globals->r2c.p2=0;
  globals->r3c.p2=0;
  globals->r4c.p2=0;
  globals->r5c.p2=0;
  globals->r6c.p2=0;
  globals->r7c.p2=0;
  globals->r8c.p2=0;
  globals->rnpc.p2=0;
  globals->rnz.p2=0;
  globals->rgl.p2=0;
  globals->rlp.p2=0;
  globals->rout.p2=0;
}


/* function FRAME_INIT

Use parameters from the input frame to set up resonator coefficients. */

static void frame_init(klatt_global_ptr globals,klatt_frame_ptr frame) {
  float amp_parF1;
  float amp_parFNP;
  float amp_parF2;
  float amp_parF3;
  float amp_parF4;
  float amp_parF5;
  float amp_parF6;

  globals->original_f0 = frame->F0hz10 / 10;

  frame->AVdb  = frame->AVdb - 7;
  if (frame->AVdb < 0) frame->AVdb = 0;

  globals->amp_aspir = DBtoLIN(frame->ASP) * 0.05;
  globals->amp_frica = DBtoLIN(frame->AF) * 0.25;
  globals->par_amp_voice = DBtoLIN(frame->AVpdb);
  amp_parF1 = DBtoLIN(frame->A1) * 0.4;
  amp_parF2 = DBtoLIN(frame->A2) * 0.15;
  amp_parF3 = DBtoLIN(frame->A3) * 0.06;
  amp_parF4 = DBtoLIN(frame->A4) * 0.04;
  amp_parF5 = DBtoLIN(frame->A5) * 0.022;
  amp_parF6 = DBtoLIN(frame->A6) * 0.03;
  amp_parFNP = DBtoLIN(frame->ANP) * 0.6;
  globals->amp_bypas = DBtoLIN(frame->AB) * 0.05;
  frame->Gain0 = frame->Gain0 - 3;
  if (frame->Gain0 <= 0) frame->Gain0 = 57;

  globals->amp_gain0 = DBtoLIN(frame->Gain0);

  /* Set coefficients of variable cascade resonators */

  setabc(frame->F5hz,frame->B5hz,&(globals->r5c),globals);
  setabc(frame->F4hz,frame->B4hz,&(globals->r4c),globals);
  setabc(frame->F3hz,frame->B3hz,&(globals->r3c),globals);
  setabc(frame->F2hz,frame->B2hz,&(globals->r2c),globals);
  setabc(frame->F1hz,frame->B1hz,&(globals->r1c),globals);

  /* Set coeficients of nasal resonator and zero antiresonator */
 
  setabc(frame->FNPhz,frame->BNPhz,&(globals->rnpc),globals);
  setzeroabc(frame->FNZhz,frame->BNZhz,&(globals->rnz),globals);
  
  /* Set coefficients of parallel resonators, and amplitude of outputs */

  setabc(frame->F1hz,frame->B1phz,&(globals->r1p),globals);
  globals->r1p.a *= amp_parF1;
  setabc(frame->FNPhz,frame->BNPhz,&(globals->rnpp),globals);
  globals->rnpp.a *= amp_parFNP;
  setabc(frame->F2hz,frame->B2phz,&(globals->r2p),globals);
  globals->r2p.a *= amp_parF2;
  setabc(frame->F3hz,frame->B3phz,&(globals->r3p),globals);
  globals->r3p.a *= amp_parF3;
  setabc(frame->F4hz,frame->B4phz,&(globals->r4p),globals);
  globals->r4p.a *= amp_parF4;
  setabc(frame->F5hz,frame->B5phz,&(globals->r5p),globals);
  globals->r5p.a *= amp_parF5;
  setabc(frame->F6hz,frame->B6phz,&(globals->r6p),globals);
  globals->r6p.a *= amp_parF6;
  
  /* output low-pass filter */

  setabc((long)0.0,(long)(globals->samrate/2),&(globals->rout),globals);
}

/* function PITCH_SYNC_PAR_RESET

Reset selected parameters pitch-synchronously. */

static void pitch_synch_par_reset(klatt_global_ptr globals,klatt_frame_ptr frame) {
  long temp;
  float temp1;

  if (frame->F0hz10 > 0) {
    /* T0 is 4* the number of samples in one pitch period */

    globals->T0 = (40 * globals->samrate) / frame->F0hz10;
    globals->amp_voice = DBtoLIN(frame->AVdb);

    /* Duration of period before amplitude modulation */

    globals->nmod = globals->T0;
    if (frame->AVdb > 0) globals->nmod >>= 1;

    /* Set open phase of glottal period where  40 <= open phase <= 263 */

    globals->nopen = 4 * frame->Kopen;

    if (globals->nopen > 263) globals->nopen = 263;
    if (globals->nopen >= (globals->T0-1)) {
      globals->nopen = globals->T0 - 2;
      if(globals->quiet_flag == FALSE)
	printf("Warning: glottal open period cannot exceed T0, truncated\n");
    }

    if (globals->nopen < 40) {
      /* F0 max = 1000 Hz */
      globals->nopen = 40;    
      if(globals->quiet_flag == FALSE) {
	printf("Warning: minimum glottal open period is 10 samples.\n");
	printf("truncated, nopen = %d\n",globals->nopen);
      }
    }

    /* Reset width of "impulsive" glottal pulse */

    temp = globals->samrate / globals->nopen;

    setabc((long)0,temp,&(globals->rgl),globals);

    /* Make gain at F1 about constant */

    temp1 = globals->nopen *.00833;
    globals->rgl.a *= temp1 * temp1;
    
  }

  else 
  {
    globals->T0 = 4;                     /* Default for f0 undefined */
    globals->amp_voice = 0.0;
    globals->nmod = globals->T0;
  }

  /* Reset these pars pitch synchronously or at update rate if f0=0 */

  if ((globals->T0 != 4) || (globals->ns == 0)) {
    /* Set one-pole low-pass filter that tilts glottal source */

    globals->decay = (0.033 * frame->TLTdb);

    if (globals->decay > 0.0) 
      globals->onemd = 1.0 - globals->decay;
    else 
      globals->onemd = 1.0;
  }
}

/* function DBTOLIN - Convert from decibels to a linear scale factor

Conversion table, db to linear, 87 dB --> 32767
                                86 dB --> 29491 (1 dB down = 0.5**1/6)
                                 ...
                                81 dB --> 16384 (6 dB down = 0.5)
                                 ...
                                 0 dB -->     0
 
The just noticeable difference for a change in intensity of a vowel
is approximately 1 dB.  Thus all amplitudes are quantized to 1 dB
steps. */

static float DBtoLIN(long dB) {
  float lgtemp;
  static float amptable[88] = 
  {
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.0, 7.0,
    8.0, 9.0, 10.0, 11.0, 13.0, 14.0, 16.0, 18.0, 20.0, 22.0, 25.0, 28.0, 32.0,
    35.0, 40.0, 45.0, 51.0, 57.0, 64.0, 71.0, 80.0, 90.0, 101.0, 114.0, 128.0,
    142.0, 159.0, 179.0, 202.0, 227.0, 256.0, 284.0, 318.0, 359.0, 405.0,
    455.0, 512.0, 568.0, 638.0, 719.0, 811.0, 911.0, 1024.0, 1137.0, 1276.0,
    1438.0, 1622.0, 1823.0, 2048.0, 2273.0, 2552.0, 2875.0, 3244.0, 3645.0, 
    4096.0, 4547.0, 5104.0, 5751.0, 6488.0, 7291.0, 8192.0, 9093.0, 10207.0, 
    11502.0, 12976.0, 14582.0, 16384.0, 18350.0, 20644.0, 23429.0,
    26214.0, 29491.0, 32767
  };

  if ((dB < 0) || (dB > 87)) return(0);

  lgtemp=amptable[dB] * .001;
  return(lgtemp);
}

