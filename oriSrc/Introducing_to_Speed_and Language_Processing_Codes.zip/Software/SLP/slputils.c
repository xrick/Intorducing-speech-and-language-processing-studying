#include <stdio.h>
#include <stdlib.h>
#include "nrutil.h"

/* SLPUTILS.C									*/

short int *signal_in(char *infile, int *length)

/* Reads a signal from a disk file into a variable, x_in.			*/
/* The length of the signal (in shorts) is returned in the variable *length.	*/

{
	FILE *fid;
	int j, status;
	short int input, *x_in;

/* Open the file */

	fid = fopen(infile,"rb");
	if(fid == NULL) {
		printf("Error opening %s\n",infile);
		exit(1);
	}

/* First read in shorts, until the end of the file is reached, just to measure the file */
	j = 0;
	while(!feof(fid)) {
		status = fread(&input,sizeof(short int),1,fid);
		if(status != 1) {
			break;
		}
		j++;
	}
	(*length) = j;
	fclose(fid);

/* Allocate memory, and read in the file again	*/

	x_in = (short int *) calloc(*length,sizeof(short int));

/* Open the file again */

	fid = fopen(infile,"rb");
	if(fid == NULL) {
		printf("Error re-opening %s\n",infile);
		exit(1);
	}

	for(j=0;j<*length;j++) {
		status = fread(&input,sizeof(short int),1,fid);
		x_in[j] = input;
		if(status != 1) {
			printf("Read error at sample %d\n",j);
			exit(1);
		}
	}
	*length = j;
	fclose(fid);
	return(x_in);
}

void signal_out(int *length, short int *x_out, char *outfile)
{
	FILE *fid;
	int status;

	fid = fopen(outfile,"wb");
	if(fid == NULL) {
		printf("Can't open %s\n",outfile);
		printf("It may be in use by another application.\n");
		exit(1);
	}
	status = fwrite(x_out,sizeof(short int),*length,fid);
	if(status < *length) {
		printf("Error writing %s\n",outfile);	
		exit(1);
	}
	fclose(fid);
}
