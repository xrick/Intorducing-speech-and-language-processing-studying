#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "slputils.c"

/*****************************************************************

MEANSOF40.C - Filters infile to produce outfile using running means
of 40 (low-pass filtering below 200Hz at 8000 samples/s).

******************************************************************/

void main(int argc, char *argv[])
{
	char *infile, *outfile;
	int *length, i,j;
	short int *x, *y, *signal_in();
	float yf;
	void signal_out();
	
	if (argc != 3) {
		printf("usage: meansof40 input_file output_file\n");
		exit(1);
	}
	infile = argv[1];
	outfile = argv[2];

	x = signal_in(infile,length);
	y = (short *) calloc(*length,sizeof(short int));

	for (i = 40 ; i < *length ; i++) {
		yf = 0;
		for (j = 0;j<40;j++) yf += (x[i-j]/40);
		y[i-40] = (short int) yf;
	}

	signal_out(length,y,outfile);
}
