#include <stdio.h>
#include "slputils.c"
#define k 14		/* Number of coefficients */

/* LPCSYN.C									*/
/* Reads an excitation signal from errfile into x_in, and vectors of k LPC	*/
/* coefficients from infile. Uses linear prediction to model the signal	*/
/* and writes it to outfile.							*/

int main(int argc, char *argv[])
{
	short int *e_in, *signal_in(), *x_out;
	char *errfile, *coeffs, *outfile;
	int frame, i, j, n, prev, next, *length, n_frames;
	float data[81], *xms, *c, *lp, coeff;
	void signal_out();
	FILE *fid;

	if (argc != 4) {
		printf("usage: lpcsyn excitation_file lp_coefficients output_file\n");
		exit(1);
	}
	errfile = argv[1];
	coeffs = argv[2];
	outfile = argv[3];

	e_in = signal_in(errfile,length);
	n_frames = (*length)/80;
	fid = fopen(coeffs,"rb");

	c = (float *) calloc((*length)*k,sizeof(float));
/*	printf("memory for c allocated: %d floats\n",(*length)*k);	*/

	for (frame=0;frame<n_frames;frame++) {
		for (j=0;j<k;j++) {
			fread(&coeff,sizeof(float),1,fid);
			c[(frame+1)*80*k-k+j] = coeff;
		}
	}
	fclose(fid);

/* For the first LPC frame, use the first analysis vector for every sample	*/

	for (i=0;i<=78;i++) {
		for (j=0;j<=k-1;j++) {
			c[i*k+j] = c[79*k+j];
		}
	}

/* For frames 1..n_frames, interpolate the intermediate LPC vectors		*/
	for (frame=1;frame<n_frames;frame++) {
		prev = frame*k*80-k;
		next = prev+k*80;
		for (i=0;i<79;i++) {
			for (j=0;j<=k-1;j++) {
				c[prev+k+k*i+j] = c[prev+j]+((float) i/80.0)*(c[prev+j]-c[next+j]);
			}
		}
	}

/* Model x_out									*/
	lp = (float *) calloc(*length,sizeof(float));	/* predicted signal	*/
	x_out = (short int *) calloc(*length,sizeof(short int));
 
	for (i=k;i<(*length);i++) {
		j = (i-1)*k;
		lp[i] = 0;
		for (n=0;n<=k-1;n++)
			lp[i] = lp[i] -c[j+n]*lp[i-n-1];
		lp[i] = -lp[i];
		x_out[i] = (short int) lp[i]+e_in[i];	
		lp[i] += e_in[i];
	}
	signal_out(length,x_out,outfile);
        return 0;
}

