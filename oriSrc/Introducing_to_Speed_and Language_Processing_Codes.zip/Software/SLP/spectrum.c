#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "slputils.c"
#include "four1.c"

/* SPECTRUM.C									*/
/* Spectral analysis using a 512-point FFT				*/

int main(int argc, char *argv[])
{
   short int *x_in, *signal_in();
   char *infile, *sampleno, *endcp;
   int sample, i, *length;
   float wvalue, twopi, arg, logpsd[512];
   float data[1024];			/* 512 complex data points	*/
   void four1();

   if (argc != 3) {
      printf("usage: spectrum input_file sample_number [ >  output_file ]\n");
      exit(1);
   }
   infile = argv[1];
   sampleno = argv[2];

   x_in = signal_in(infile,length);
   sample = (int) strtoul(sampleno,&endcp,10);

/* Windowing using 512-point Hanning window and coercion to floats */

   twopi = 8.0*atan(1.0);            		/* calculate 2*PI */
   arg = twopi/511.0;
   for (i=0;i<=511;i++) {
      wvalue = 0.5 - 0.5*cos(arg*i);
      data[2*i] = x_in[sample+i-256] * wvalue;
      data[2*i+1] = 0.0;
   }

   four1(data-1,512,1);

/* In the log power spectral density, magnitudes are in dB		*/
/* in steps of SampleRate/512 Hz (31.25Hz at 16000 samples/s).	*/

   printf("f (Hz)\tAmplitude (dB)\n");

   for (i=0;i<=256;i++) {
      logpsd[i] = data[2*i];
      logpsd[i] *= logpsd[i];
      logpsd[i] += SQR(data[2*i+1]);
      logpsd[i] = 10*log10(logpsd[i]);
      printf("%d\t%.2f\n",(int) (i*31.25),logpsd[i]);
   }
   return 0;
}

