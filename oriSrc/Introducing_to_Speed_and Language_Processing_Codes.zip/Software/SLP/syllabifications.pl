/* SYLLABIFICATIONS.PL								*/

syllable_sequence([S],In,Out):- syllable(In,Out),
	append(S,Out,In).
syllable_sequence(Sylls,In,Out):- syllable(In,Mid), syllable_sequence(Rest,Mid,Out),
	append(S1,Mid,In),
	append([S1],[Rest],Sylls).


