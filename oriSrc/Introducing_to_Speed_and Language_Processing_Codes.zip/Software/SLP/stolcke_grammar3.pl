/* stolcke_grammar3.pl */

s(P) --> np(P1), vp(P2),
    {P is 1 * P1 * P2}.
np(P) --> det(P1), n(P2),
    {P is 1 * P1 * P2}.
vp(P) --> vt(P1), np(P2),
    {P is 0.364 * P1 * P2}.
vp(P) --> vi(P1), pp(P2),
    {P is 0.636 * P1 * P2}.
pp(P) --> p(P1), np(P2),
    {P is 1 * P1 * P2}.

det(1) --> [a].
n(0.273) --> [circle].
n(0.318) --> [square].
n(0.409) --> [triangle].
vt(1) --> [touches].
vi(1) --> [is].
p(0.5) --> [above].
p(0.5) --> [below].
