/* DOG_GRAMMAR.PL					*/

ip --> np, vp.

np --> n.
np --> adj, n.
np --> adj, adj, n.
np --> det, n.
np --> det, adj, n.
np --> det, adj, adj, n.

vp --> v, np.
vp --> v, pp.

pp --> p, np.

det --> [the].
det --> [a].
det --> [an].

n --> [dogs].
n --> [runs].
n --> [fox].

adj --> [quick].
adj --> [brown].
adj --> [lazy].

v --> [jumped].
v --> [runs].
v --> [dogs].

p --> [over].
p --> [onto].
p --> [in].
p --> [under].

/* Generate all sentences */

loop:- ip(S,[]), write(S), nl, fail.


