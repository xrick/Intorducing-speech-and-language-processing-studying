#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "slputils.c"

/* VOICING.C 									*/
/* Low-pass filters infile using a 400Hz low-pass filter.		*/
/* Calculates running rms amplitude over a 100-sample window.	*/
/* Outputs voiced/unvoiced decision per sample, to outfile. 	*/

int main(int argc, char *argv[]) {
   char *infile, *outfile;
   int *length, i;
   short int *x, *y, *signal_in();
   float *yf, *yfsqr, *sumsq;
   void signal_out();

   /* Coefficients for a low-pass filter */
   /* (<400 Hz at 16000 samples/s) */		
 float a[6] = {0, -4.4918, 8.0941, -7.3121, 3.311, -0.6011};
 float b[6] = {2.34E-6, 1.17E-5, 2.34E-5, 2.34E-5, 1.17E-5, 2.34E-6};

   if (argc != 3) {
      printf("usage: voicing input_file output_file\n");
      exit(1);
   }
   infile = argv[1];
   outfile = argv[2];

   x = signal_in(infile,length);
   y = (short *) calloc(*length,sizeof(short int));
   yf = (float *) calloc(*length,sizeof(float));
   yfsqr = (float *) calloc(*length,sizeof(float));
   sumsq = (float *) calloc(*length,sizeof(float));

   for (i = 6 ; i <= *length ; i++) {
      yf[i] = (b[0]*x[i] + b[1]*x[i-1] + b[2]*x[i-2] 
        + b[3]*x[i-3] + b[4]*x[i-4] + b[5]*x[i-5] - a[1]*yf[i-1] 
        - a[2]*yf[i-2] - a[3]*yf[i-3] - a[4]*yf[i-4] - a[5]*yf[i-5]);
      yfsqr[i] = yf[i]*yf[i];
   }

/* sumsq is used to store sums of squares */
   for (i = 1; i<=158; i++) sumsq[i] = (sumsq[i-1]+yfsqr[i]);
   for (i = 159 ; i <= *length ; i++)
      sumsq[i] = (sumsq[i-1] - yfsqr[i-160]) + yfsqr[i];
   for (i = 0; i <= *length; i++)
      y[i] = (sqrt(sumsq[i]/160) > 600);	/* threshold */

   signal_out(length,y,outfile);
   return 0;
}

