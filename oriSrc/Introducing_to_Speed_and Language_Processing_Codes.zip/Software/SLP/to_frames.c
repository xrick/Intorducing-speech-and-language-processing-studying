#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "slputils.c"

/* to_frames.c 
Down-samples a signal in infile (e.g. f0, voice) to 80-sample intervals. */

int main(int argc, char *argv[]) {
   char *infile;
   int *length, i;
   short int *x, *signal_in();

   if (argc != 2) {
      printf("usage: to_frames input_file [ > output_file ]\n");
      exit(1);
   }
   infile = argv[1];

   x = signal_in(infile,length);

   for (i = 0; i < *length; i++) {
      if ((i+1)%80 == 0) printf("%d\n",x[i]);
   }
   return 0;
}

