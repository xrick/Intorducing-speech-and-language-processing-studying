/* stolcke_grammar2.pl */

s(D1) --> np(D2), vp(D3),
    {append3([1],D2,D3,D1)}.
np(D1) --> det(D2), n(D3),
    {append3([2],D2,D3,D1)}.
vp(D1) --> vt(D2), np(D3),
    {append3([3],D2,D3,D1)}.
vp(D1) --> vi(D2), pp(D3),
    {append3([4],D2,D3,D1)}.
pp(D1) --> p(D2), np(D3),
    {append3([5],D2,D3,D1)}.

det([6]) --> [a].
n([7]) --> [circle].
n([8]) --> [square].
n([9]) --> [triangle].
vt([10]) --> [touches].
vi([11]) --> [is].
p([12]) --> [above].
p([13]) --> [below].

append3(A,B,C,D):-
    append(A,B,X),
    append(X,C,D).

append([],X,X).
append([H|T],X,[H|T2]):- append(T,X,T2).
