/* DOG_GRAMMAR3.PL						*/
/* Same as dog_grammar.pl, with an extra argument on each rule,	*/
/* in which to build and store a parse tree.			*/

ip(ip:[NP,VP]) --> np(NP), vp(VP).

np(np:[N]) --> n(N).
np(np:[ADJ,N]) --> adj(ADJ), n(N).
np(np:[ADJ1,ADJ2,N]) --> adj(ADJ1), adj(ADJ2), n(N).
np(np:[DET,N]) --> det(DET), n(N).
np(np:[DET,ADJ,N]) --> det(DET), adj(ADJ), n(N).
np(np:[DET,ADJ1,ADJ2,N]) --> det(DET), adj(ADJ1), adj(ADJ2), n(N).

vp(vp:[V,NP]) --> v(V), np(NP).
vp(vp:[V,PP]) --> v(V), pp(PP).

pp(pp:[P,NP]) --> p(P), np(NP).

det(det:[the]) --> [the].
det(det:[a]) --> [a].
det(det:[an]) --> [an].

n(n:[dogs]) --> [dogs].
n(n:[runs]) --> [runs].
n(n:[fox]) --> [fox].

adj(adj:[quick]) --> [quick].
adj(adj:[brown]) --> [brown].
adj(adj:[lazy]) --> [lazy].

v(v:[jumped]) --> [jumped].
v(v:[runs]) --> [runs].
v(v:[dogs]) --> [dogs].

p(p:[over]) --> [over].
p(p:[onto]) --> [onto].
p(p:[in]) --> [in].
p(p:[under]) --> [under].

/* Generate all sentences */

loop:- ip(Tree,IP,[]), write(IP), write(' '), write(Tree), nl, fail.


