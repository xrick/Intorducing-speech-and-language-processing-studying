#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "slputils.c"

/* NORMALIZE.C 
Normalizes the amplitude of infile by amplifying it so that the maximum or minimum signal
level uses the entire 16-bit range */

int main(int argc, char *argv[]) {
   char *infile, *outfile;
   int *length, i;
   short int *x, *y, *signal_in(), max=0, min=0;
   void signal_out();
   float factor;

   if (argc != 3) {
      printf("usage: normalize input_file output_file\n");
      exit(1);
   }
   infile = argv[1];
   outfile = argv[2];

   x = signal_in(infile,length);
   y = (short *) calloc(*length,sizeof(short int));

   for (i = 0 ; i <= *length ; i++) {
      if (x[i] > max) max = x[i];
      if (x[i] < min) min = x[i];
   }

   if (max > -min) factor = 32000.0/max; 
   else factor = -32000.0/min;

   for (i = 0 ; i <= *length ; i++) {
      y[i] = (short int) (x[i]*factor);
   }

   signal_out(length,y,outfile);
   return 0;
}

