/* SENTENCE_GRAMMAR.PL							*/
/* Simple syntactic DCG, after Clocksin & Mellish ch.9	*/

sentence --> noun_phrase, verb_phrase.

noun_phrase --> determiner, noun.

verb_phrase --> verb, noun_phrase.
verb_phrase --> verb.

determiner --> [the].

noun --> [apple].
noun --> [man].

verb --> [eats].
verb --> [sings].

/* Generate all sentences */

loop:- sentence(S,[]), write(S), nl, fail.

