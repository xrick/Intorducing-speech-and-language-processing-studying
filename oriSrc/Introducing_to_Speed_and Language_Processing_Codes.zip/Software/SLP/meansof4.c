#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "slputils.c"

/* MEANSOF4.C - Filters infile to produce outfile using running 
means of 4 with coefficients b1-b4. */

int main(int argc, char *argv[]) {
   char *infile, *outfile;
   int i, *length;
   short int *x, *y, *signal_in();
   void signal_out();

   /* Coefficients for running means of 4	*/	
   float b[4] = {0.25, 0.25, 0.25, 0.25};

   if (argc != 3) {
      printf("usage: meansof4 input_file output_file\n");
      exit(1);
   }
   infile = argv[1];
   outfile = argv[2];

   x = signal_in(infile,length);
   y = (short *) calloc(*length,sizeof(short int));

   for (i = 4 ; i < *length ; i++)
      y[i] = (int) (b[0]*x[i]+b[1]*x[i-1]+b[2]*x[i-2]+b[3]*x[i-3]);
   signal_out(length,y,outfile);
   return 0;
}

