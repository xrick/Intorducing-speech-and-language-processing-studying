#include <stdio.h>
#include <stdlib.h>
#include "proto.h"
#include "parwave.h"

/*
title:  SIMPLE_KLATT.C

This program is based on a C implementation of the Klatt synthesizer by Jon Iles
and Nick Ing-Simmons (see klatt.c and parwave.c). 
This file contains a simple interface to simple_parwave.c. That function, as the 
name suggests, converts frames of parameters into a waveform. The parwave function 
itself is a translation of the Dennis Klatt's original Fortran code, as published 
in JASA. John Coleman cut out a number of options in order to make it simpler, and 
added the option -r 0, to get the glottal wave as the output.
*/

/* 1. function prototypes */

static void usage PROTO((void));

/* 2. function USAGE

Displays the command line options.
*/

static void usage()

{
  printf("Options...\n");
  printf("-h Displays this message\n");
  printf("-i <infile> sets input filename\n");
  printf("-o <outfile> sets output filename\n");
  printf("-q quiet - print no messages\n");
  printf("-n <number> Number of formants in cascade branch.\n");
  printf("   Default is 5\n");
  printf("-s <n> set sample rate\n");
  printf("-f <n> set number of milliseconds per frame, default 5\n");
  printf("-r <type> output 16 bit signed integers rather than ASCII\n");
  printf("   integers. Type = 1 gives high byte first (Motorola convention), \n");
  printf("   Type = 2 gives low byte first (Intel convention).\n");
}

/* 3. function MAIN */

int main(argc,argv)

int argc;
char *argv[];  

{
  extern char *optarg;
  char c;
  char infile[80];
  char outfile[80];
  FILE *infp;
  FILE *outfp;
  int result;
  flag done_flag;
  long value;
  int iwave[MAX_SAM];
  int isam;
  int icount;
  int par_count;   
  int nmspf_def;
  klatt_global_t globals;
  klatt_frame_t frame;
  long *frame_ptr;
  unsigned char high_byte;
  unsigned char low_byte;
  flag raw_flag;
  flag raw_type;

/* 4. */

  if(argc==1)
  {
    usage();
    exit(1);
  }

/* 5. set up default values */

  globals.quiet_flag = FALSE;
  globals.synthesis_model = CASCADE_PARALLEL;
  globals.samrate = 10000;
  globals.glsource = IMPULSIVE;
  nmspf_def = 5;
  globals.nfcascade = 5;
  raw_flag = FALSE;

/* 6. get the details from the command line */

  while((c = getopt(argc,argv,"i:o:s:f:n:qhr:"))!=EOF)
  {
    switch(c)
    {
    case 'i':
      strcpy(infile,optarg);
      break;
    case 'o':
      strcpy(outfile,optarg);
      break;
    case 'q':
      globals.quiet_flag = TRUE;
      break;
    case 's':
      globals.samrate = atoi(optarg);
      break;
    case 'f':
      nmspf_def = atoi(optarg);
      break;
    case 'h':
      usage();
      exit(1);
      break;
    case 'n':
      globals.nfcascade = atoi(optarg);
      break;
    case 'r':
      raw_flag = TRUE;
      raw_type = (flag) atoi(optarg);
      break;
    }
  }


/* 7. work out the number of samples per frame */

  globals.nspfr = (globals.samrate * nmspf_def) / 1000;

/* 8. open the input and output files */

    infp = fopen(infile,"r");
    if(infp==NULL)
    {
      perror("can't open input parameter file");
      exit(1);
    }

    if(raw_flag == TRUE)		
	outfp = fopen(outfile,"wb");	/* binary output */
    else
        outfp = fopen(outfile,"w");	/* ASCII output */
    if(outfp==NULL)
    {
      perror("can't open output file");
      exit(1);
    }

/* 9. Here's where it all gets going */

  icount=0;
  done_flag = FALSE;
  parwave_init(&globals);
  frame_ptr = (long*) &frame;

/* 10. read in the parameter file ... */

  while(done_flag == FALSE)
  {
    for (par_count = 0; par_count < NPAR; ++par_count)
    {
      result = fscanf(infp,"%i",&value);
      frame_ptr[par_count] = value;
    }

/* 11. ... until the end of the file is reached. */
    
    if(result == EOF)
    {
      done_flag = TRUE;
    }
    else
    {

/* 12. Call to simple_parwave.c */

      parwave(&globals,&frame,&iwave[0]);

/* 13. Print a running count of which frame is being processed */

      if(globals.quiet_flag == FALSE)
      {
	printf("\rFrame %i",icount);
	fflush(stdout);
      }

      for (isam = 0; isam < globals.nspfr; ++ isam) 
      { 
	if(raw_flag == TRUE)		/* 16-bit binary output */
	{

	  low_byte = iwave[isam] & 0xff;
	  high_byte = iwave[isam] >> 8;

	  if(raw_type==1) /* fwrite(&iwave[isam],sizeof(short int),1,outfp); */
	  {
	    fprintf(outfp,"%c%c",high_byte,low_byte);
	  }
	  else
	  {
	    fprintf(outfp,"%c%c",low_byte,high_byte);
	  }
	}

	else				/* ASCII output */
	{
	  fprintf(outfp,"%i\n",iwave[isam]);
	}
      }
      icount++;
    }
  }

/* 15. Finish off and tidy up */

  if(strcmp(infile,"")!=0)
  {
    fclose(infp);
  }

  if(strcmp(outfile,"")!=0)
  {
    fclose(outfp);
  }

  if(globals.quiet_flag == FALSE)
  {
    printf("\nDone\n");
  }
  return 0;
}

























